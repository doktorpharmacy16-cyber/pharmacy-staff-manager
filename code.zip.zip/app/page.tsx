'use client';
import { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';

// सीधे यहीं कनेक्शन इनिशियलाइज़ कर दिया गया है
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export default function Home() {
  const [employees, setEmployees] = useState<any[]>([]);
  const [name, setName] = useState('');
  const [role, setRole] = useState('Pharmacist');
  const [phone, setPhone] = useState('');
  const [salary, setSalary] = useState('');

  useEffect(() => {
    fetchEmployees();
  }, []);

  async function fetchEmployees() {
    const { data } = await supabase.from('employees').select('*');
    if (data) setEmployees(data);
  }

  async function addEmployee(e: React.FormEvent) {
    e.preventDefault();
    if (!name || !phone || !salary) return;
    const { error } = await supabase.from('employees').insert([
      { name, role, phone, base_salary: Number(salary) }
    ]);
    if (!error) {
      setName('');
      setPhone('');
      setSalary('');
      fetchEmployees();
      alert('कर्मचारी सफलतापूर्वक जुड़ गया!');
    } else {
      alert('Error: ' + error.message);
    }
  }

  async function markAttendance(empId: string) {
    const time = new Date().toLocaleTimeString('en-IN', { hour12: false });
    const { error } = await supabase.from('attendance').insert([
      { employee_id: empId, check_in: time, status: 'Present' }
    ]);
    if (!error) {
      alert('हाजिरी (Punch In) दर्ज हो गई!');
    } else {
      alert('Error: ' + error.message);
    }
  }

  return (
    <main className="p-6 max-w-4xl mx-auto bg-white min-h-screen font-sans text-slate-800">
      <h1 className="text-2xl font-bold mb-6 text-slate-900 border-b pb-3">मेडिकल स्टोर स्टाफ मैनेजमेंट</h1>

      {/* नया स्टाफ जोड़ने का फॉर्म */}
      <form onSubmit={addEmployee} className="grid grid-cols-1 sm:grid-cols-4 gap-3 mb-8 p-4 bg-slate-50 rounded-lg border border-slate-200">
        <input 
          placeholder="स्टाफ का नाम" 
          value={name} 
          onChange={(e) => setName(e.target.value)} 
          className="border border-slate-300 p-2 rounded text-sm focus:outline-blue-500" 
          required 
        />
        <input 
          placeholder="मोबाइल नंबर" 
          value={phone} 
          onChange={(e) => setPhone(e.target.value)} 
          className="border border-slate-300 p-2 rounded text-sm focus:outline-blue-500" 
          required 
        />
        <input 
          type="number" 
          placeholder="मासिक सैलरी (₹)" 
          value={salary} 
          onChange={(e) => setSalary(e.target.value)} 
          className="border border-slate-300 p-2 rounded text-sm focus:outline-blue-500" 
          required 
        />
        <button type="submit" className="bg-blue-600 text-white rounded p-2 text-sm font-semibold hover:bg-blue-700 transition">
          + स्टाफ जोड़ें
        </button>
      </form>

      {/* स्टाफ लिस्ट */}
      <div className="space-y-3">
        <h2 className="text-lg font-semibold text-slate-700">स्टाफ लिस्ट ({employees.length})</h2>
        {employees.length === 0 ? (
          <p className="text-sm text-slate-500">अभी कोई स्टाफ नहीं जुड़ा है। ऊपर दिए गए फॉर्म से जोड़ें।</p>
        ) : (
          employees.map((emp) => (
            <div key={emp.id} className="flex justify-between items-center p-4 border border-slate-200 rounded-lg bg-slate-50">
              <div>
                <p className="font-semibold text-slate-900">{emp.name} <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded ml-2">{emp.role}</span></p>
                <p className="text-xs text-slate-500 mt-1">फोन: {emp.phone} | मासिक सैलरी: ₹{emp.base_salary}</p>
              </div>
              <button 
                onClick={() => markAttendance(emp.id)} 
                className="bg-emerald-600 text-white px-4 py-2 rounded text-xs font-semibold hover:bg-emerald-700 transition"
              >
                हाजिरी लगाएं (Punch In)
              </button>
            </div>
          ))
        )}
      </div>
    </main>
  );
}